
# python -m yolox.tools.train -f exps/example/custom/yolox_nano_bre_1024.py -d 1 -b 32 --fp16 -o -c pretrains/yolox_nano.pth

# python -m yolox.tools.train -f exps/example/custom/yolox_nano_bre_416.py -d 1 -b 32 --fp16 -o -c pretrains/yolox_nano.pth

# python -m yolox.tools.train -f exps/example/custom/yolox_nano_bre_640.py -d 1 -b 32 --fp16 -o -c pretrains/yolox_nano.pth

# python -m yolox.tools.train -f exps/example/custom/yolox_nano_bre_768.py -d 1 -b 32 --fp16 -o -c pretrains/yolox_nano.pth




# python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_416_scale.py -d 1 -b 64 --fp16 -o -c pretrains/yolox_tiny.pth

# python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_640.py -d 1 -b 64 --fp16 -o -c pretrains/yolox_tiny.pth

# python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_768.py -d 1 -b 64 --fp16 -o -c pretrains/yolox_tiny.pth

# python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_1024.py -d 1 -b 32 --fp16 -o -c pretrains/yolox_tiny.pth



python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_1024.py -d 1 -b 32 -o -c pretrains/yolox_tiny.pth --fp16

python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_768.py -d 1 -b 32 -o -c pretrains/yolox_tiny.pth --fp16

python -m yolox.tools.train -f exps/example/custom/yolox_tiny_bre_640.py -d 1 -b 32 -o -c pretrains/yolox_tiny.pth --fp16


