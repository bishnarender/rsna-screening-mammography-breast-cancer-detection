import os

# Thanks to Lazy Loading, programs are able to only load kernels they are actually going to use, saving time on initialization. 
# This reduces memory overhead, both on GPU memory and host memory
os.environ['CUDA_MODULE_LOADING'] = 'LAZY'

import sys

import cv2
import numpy as np
import torch
import torchvision

from YOLOX.torch2trt.torch2trt.torch2trt import TRTModule
#from YOLOX.torch2trt.torch2trt.torch2trt import TRTModule

from torch.nn import functional as F

_TORCH_VER = [int(x) for x in torch.__version__.split(".")[:2]]
_TORCH11X = (_TORCH_VER >= [1, 10])


def meshgrid(*tensors):
    if _TORCH11X:
        return torch.meshgrid(*tensors, indexing="ij")
    else:
        return torch.meshgrid(*tensors)


def extract_roi_otsu(img, gkernel=(5, 5)):
    """
    WARNING: this function modify input image inplace.
    In global thresholding, we used an arbitrary chosen value as a threshold. In contrast, Otsu's method avoids having to choose a value and determines it automatically.    
    """
    # img.shape => (416, 381)
    ori_h, ori_w = img.shape[:2]
    
    # clip percentile: implant, white lines
    upper = np.percentile(img, 95)
    # upper => 147.0
    img[img > upper] = np.min(img)
    # img.shape => (416, 381)
    
    # Gaussian filtering to reduce noise (optional)
    if gkernel is not None:
        img = cv2.GaussianBlur(img, gkernel, 0)
    _, img_bin = cv2.threshold(img, 0, 255,
                               cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # dilation to improve contours connectivity
    element = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3), (-1, -1))
    img_bin = cv2.dilate(img_bin, element)
    cnts, _ = cv2.findContours(img_bin, cv2.RETR_EXTERNAL,
                               cv2.CHAIN_APPROX_SIMPLE)
    if len(cnts) == 0:
        return None, None, None
    areas = np.array([cv2.contourArea(cnt) for cnt in cnts])
    select_idx = np.argmax(areas)
    cnt = cnts[select_idx]
    area_pct = areas[select_idx] / (img.shape[0] * img.shape[1])
    x0, y0, w, h = cv2.boundingRect(cnt)
    
    # min-max for safety only
    # x0, y0, x1, y1
    x1 = min(max(int(x0 + w), 0), ori_w)
    y1 = min(max(int(y0 + h), 0), ori_h)
    x0 = min(max(int(x0), 0), ori_w)
    y0 = min(max(int(y0), 0), ori_h)
    return [x0, y0, x1, y1], area_pct, None


class RoiExtractor:

    def __init__(self,
                 engine_path,
                 input_size,
                 num_classes,
                 conf_thres=0.5,
                 nms_thres=0.9,
                 class_agnostic=False,
                 area_pct_thres=0.04,
                 hw=None,
                 strides=None,
                 exp=None):
        self.input_size = input_size
        self.input_h, self.input_w = input_size
        self.num_classes = num_classes
        self.conf_thres = conf_thres
        self.nms_thres = nms_thres
        self.class_agnostic = class_agnostic
        self.area_pct_thres = area_pct_thres

        model = TRTModule()
        model.load_state_dict(torch.load(engine_path))
        self.model = model
        if hw is None or strides is None:
            assert exp is not None
            self._set_meta(exp)
        else:
            # [torch.Size([80, 80]), torch.Size([40, 40]), torch.Size([20, 20])]
            self.hw = hw
            # [8, 16, 32]
            self.strides = strides

    def _set_meta(self, exp):
        assert exp is not None
        print("Start probing model metadata..")
        # dummy infer
        torch_model = exp.get_model().cuda().eval()
        _dummy = torch.ones(1, 3, exp.test_size[0], exp.test_size[1]).cuda()
        torch_model(_dummy)
        # set attributes
        self.hw = torch_model.head.hw
        self.strides = torch_model.head.strides
        # cleanup
        del torch_model, _dummy
        import gc
        _ = gc.collect()
        torch.cuda.empty_cache()
        print('Done probbing model metadata..')

    def decode_outputs(self, outputs):
        # outputs.shape => torch.Size([1, 3549, 6])
        dtype = outputs.type()
        grids = []
        strides = []
        
        # self.hw, self.strides => [(52, 52), (26, 26), (13, 13)], [8, 16, 32]
        for (hsize, wsize), stride in zip(self.hw, self.strides):
            # hsize, wsize, stride => 52, 52, 8
            # torch.arange(hsize) => tensor([ 0,  1,  2,  3, ..., 50, 51])
            yv, xv = meshgrid([torch.arange(hsize), torch.arange(wsize)])
            # yv =>
            # tensor([[ 0,  0,  0,  ...,  0,  0,  0],
            #         [ 1,  1,  1,  ...,  1,  1,  1],
            #         ...,
            #         [50, 50, 50,  ..., 50, 50, 50],
            #         [51, 51, 51,  ..., 51, 51, 51]])
            
            # xv =>            
            # tensor([[ 0,  1,  2,  ..., 49, 50, 51],
            #         [ 0,  1,  2,  ..., 49, 50, 51],
            #         ...,
            #         [ 0,  1,  2,  ..., 49, 50, 51],
            #         [ 0,  1,  2,  ..., 49, 50, 51]])            
            
            # yv.shape, xv.shape => torch.Size([52, 52]), torch.Size([52, 52])
            # torch.stack((xv, yv), 2).shape => torch.Size([52, 52, 2])
            grid = torch.stack((xv, yv), 2).view(1, -1, 2)
            # 52*52 = 2704
            # grid.shape => torch.Size([1, 2704, 2]) 
            
            grids.append(grid)
            shape = grid.shape[:2]
            # shape => torch.Size([1, 2704])
            
            # torch.full((*shape, 1), stride).shape => torch.Size([1, 2704, 1])
            # torch.full((*shape, 1), stride) =>
            # tensor([[[8],
            #          [8],
            #          ...,
            #          [8],
            #          [8]]])            
            strides.append(torch.full((*shape, 1), stride))

            # my break
            # break

        grids = torch.cat(grids, dim=1).type(dtype)
        # 52*52 + 26*26 + 13*13 = 3549
        # grids.shape => torch.Size([1, 3549, 2])
        strides = torch.cat(strides, dim=1).type(dtype)
        # strides.shape => torch.Size([1, 3549, 1])
        
        # outputs.shape => torch.Size([1, 3549, 6])
        # torch.exp(...) => returns a new tensor with the exponential of the elements of the input tensor input.
        outputs = torch.cat(
            [(outputs[..., 0:2] + grids) * strides,
             torch.exp(outputs[..., 2:4]) * strides, outputs[..., 4:]],
            dim=-1)
        
        # outputs.shape => torch.Size([1, 3549, 6])
        return outputs

    def post_process(self,
                     pred,
                     conf_thres=0.5,
                     nms_thres=0.9,
                     class_agnostic=False):
        # class_agnostic => False
        # .new() => constructs a new tensor of the "same data type" and "same content" as self tensor.
        box_corner = pred.new(pred.shape)
        
        box_corner[:, :, 0] = pred[:, :, 0] - pred[:, :, 2] / 2
        box_corner[:, :, 1] = pred[:, :, 1] - pred[:, :, 3] / 2
        box_corner[:, :, 2] = pred[:, :, 0] + pred[:, :, 2] / 2
        box_corner[:, :, 3] = pred[:, :, 1] + pred[:, :, 3] / 2

        pred[:, :, :4] = box_corner[:, :, :4]
        
        # pred.shape => torch.Size([1, 3549, 6])
        # len(pred) => 1 => len(tensor) returns length of first dimension.
        output = [None for _ in range(len(pred))]
        
        for i, image_pred in enumerate(pred):
            # image_pred.shape => torch.Size([3549, 6])
            # image_pred.size(0) => 3549
            
            # If none are remaining => process next image
            if not image_pred.size(0):
                continue
                
            # torch.max(input, dim, ...) => Returns a namedtuple (values, indices) where values is the maximum value of each row of the input tensor in the given dimension dim.
            # Get score and class with highest confidence
            class_conf, class_pred = torch.max(image_pred[:, 5:5 + self.num_classes], 1, keepdim=True)            
            # class_conf.shape, class_pred.shape => torch.Size([3549, 1]), torch.Size([3549, 1])
            
            # class_conf.squeeze().shape => torch.Size([3549])
            conf_mask = (image_pred[:, 4] * class_conf.squeeze() >= conf_thres).squeeze()
            # conf_mask.shape => torch.Size([3549])
            
            # Detections ordered as (x1, y1, x2, y2, obj_conf, class_conf, class_pred)
            detections = torch.cat((image_pred[:, :5], class_conf, class_pred.float()), 1)
            # detections.shape => torch.Size([3549, 7])
            
            detections = detections[conf_mask]
            # detections.shape => torch.Size([9, 7])
            
            if not detections.size(0):
                continue

            if class_agnostic:
                nms_out_index = torchvision.ops.nms(
                    detections[:, :4],
                    detections[:, 4] * detections[:, 5],
                    nms_thres,
                )
            else:
                # torchvision.ops.batched_nms => performs non-maximum suppression in a batched fashion.
                nms_out_index = torchvision.ops.batched_nms(
                    detections[:, :4],
                    detections[:, 4] * detections[:, 5],
                    detections[:, 6],
                    nms_thres,
                )
                
            detections = detections[nms_out_index]
            
            # detections.shape => torch.Size([1, 7])
            
            if output[i] is None:
                output[i] = detections
            else:
                output[i] = torch.cat((output[i], detections))
            
            
        # len(output) => 1
        # output[0].shape => torch.Size([1, 7])
        return output

    def preprocess_single(self, img: torch.Tensor):
        # ori_h => original height.
        ori_h = img.size(0)
        ori_w = img.size(1)
        # ori_h, ori_w => 5355, 4915
        # self.input_h, self.input_w => 416, 416
        ratio = min(self.input_h / ori_h, self.input_w / ori_w)
        
        # ratio => 0.0776844070961718
        # img.view(1, 1, ori_h, ori_w).shape => torch.Size([1, 1, 5355, 4915])
        resized_img = F.interpolate(img.view(1, 1, ori_h, ori_w),
                                    mode="bilinear",
                                    scale_factor=ratio,
                                    recompute_scale_factor=True)[0, 0]
        
        # resized_img.shape => torch.Size([416, 381])
        # torch.full(size, fill_value, ...) => creates a tensor of size size filled with fill_value.
        # 114 value here comes from a legacy problem. You could set it to 0 or 255 or any value you like, your model could fit this value after enough training.
        padded_img = torch.full((self.input_h, self.input_w),
                                114, 
                                dtype=resized_img.dtype,
                                device='cuda')
        
        
        padded_img[:resized_img.size(0), :resized_img.size(1)] = resized_img
        
        # .unsqueeze(...) => returns a new tensor with a dimension of size one inserted at the specified position.
        # .expand(...) => passing -1 as the size for a dimension means not changing the size of that dimension.
        # padded_img.shape => torch.Size([416, 416])
        # padded_img.unsqueeze(-1).shape => torch.Size([416, 416, 1])
        padded_img = padded_img.unsqueeze(-1).expand(-1, -1, 3)
        # padded_img.shape => torch.Size([416, 416, 3])
        
        # HWC --> CHW
        padded_img = padded_img.permute(2, 0, 1)
        padded_img = padded_img.float()
        # padded_img.shape => torch.Size([3, 416, 416])
        
        return padded_img, resized_img, ratio, ori_h, ori_w

    def detect_single(self, img):
        padded_img, resized_img, ratio, ori_h, ori_w = self.preprocess_single(
            img)
      
        padded_img = padded_img.unsqueeze(0)
        # padded_img.shape => torch.Size([1, 3, 416, 416])
        
        output = self.model(padded_img)
        output = self.decode_outputs(output)
        
        # x0, y0, x1, y1, box_conf, cls_conf, cls_id
        output = self.post_process(output, self.conf_thres, self.nms_thres)[0]
        
        if output is not None:
            # output.shape => torch.Size([1, 7])
            
            output[:, :4] = output[:, :4] / ratio
            
            # re-compute: conf = box_conf * cls_conf
            output[:, 4] = output[:, 4] * output[:, 5]
            
            # output[:, 4].shape => torch.Size([1])
            # .argmax() => returns the indices of the maximum value of all elements in the input tensor.
            # select box with highest confident
            output = output[output[:, 4].argmax()]
            x0 = min(max(int(output[0]), 0), ori_w)
            y0 = min(max(int(output[1]), 0), ori_h)
            x1 = min(max(int(output[2]), 0), ori_w)
            y1 = min(max(int(output[3]), 0), ori_h)
            area_pct = (x1 - x0) * (y1 - y0) / (ori_h * ori_w)
            if area_pct >= self.area_pct_thres:
                # xyxy, area_pct, conf
                return [x0, y0, x1, y1], area_pct, output[4]

        # if YOLOX fail, try Otsu thresholding + find contours
        xyxy, area_pct, _ = extract_roi_otsu(
            resized_img.to(torch.uint8).cpu().numpy())
        
        # if both fail, use full frame
        if xyxy is not None:
            if area_pct >= self.area_pct_thres:
                print('ROI detection: using Otsu.')
                x0, y0, x1, y1 = xyxy
                x0 = min(max(int(x0 / ratio), 0), ori_w)
                y0 = min(max(int(y0 / ratio), 0), ori_h)
                x1 = min(max(int(x1 / ratio), 0), ori_w)
                y1 = min(max(int(y1 / ratio), 0), ori_h)
                return [x0, y0, x1, y1], area_pct, None
            
        print('ROI detection: both fail.')
        return None, area_pct, None